//import React from 'react'

import ThemeNavbar from "./ThemeNavbar"

const Header = () => {
  return (
   <>
    <ThemeNavbar/>
   </>
  )
}

export default Header