import { LeftOutlined } from '@ant-design/icons'
// import React from 'react'

const PrevArrow = () => {
  return (
    <>
    <button className="prevbutton border border-blue-800 rounded-full size-10 leading-5">
        <LeftOutlined/>
    </button>
    </>
  )
}

export default PrevArrow